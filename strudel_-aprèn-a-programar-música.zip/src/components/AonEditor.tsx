import React, { useRef, useState, useEffect } from 'react';
import '@strudel/repl';
import { Play, Square, CheckCircle2, XCircle, Check } from 'lucide-react';

function replaceMapped(
  mappedChars: { char: string; originalIndex: number }[],
  regex: RegExp,
  replacement: string | ((m: string, p1?: string) => string)
) {
  const r = new RegExp(regex.source, regex.flags.includes('g') ? regex.flags : regex.flags + 'g');
  const currentText = mappedChars.map(mc => mc.char).join('');
  let match;
  
  const matches: { start: number; end: number; matchStr: string; p1?: string }[] = [];
  r.lastIndex = 0;
  while ((match = r.exec(currentText)) !== null) {
    matches.push({
      start: match.index,
      end: r.lastIndex,
      matchStr: match[0],
      p1: match[1]
    });
    if (match[0].length === 0) {
      r.lastIndex++;
    }
  }
  
  for (let i = matches.length - 1; i >= 0; i--) {
    const { start, end, matchStr, p1 } = matches[i];
    const repVal = typeof replacement === 'function' ? replacement(matchStr, p1) : replacement;
    
    const origStart = mappedChars[start]?.originalIndex ?? 0;
    const origEnd = mappedChars[end - 1]?.originalIndex ?? origStart;
    
    const newSlice = Array.from(repVal).map((c, idx) => {
      const t = repVal.length > 1 ? idx / (repVal.length - 1) : 0;
      const originalIndex = Math.round(origStart + t * (origEnd - origStart));
      return { char: c, originalIndex };
    });
    
    mappedChars.splice(start, end - start, ...newSlice);
  }
}

function translateCodeAndGetMap(code: string) {
  const mappedChars = Array.from(code).map((char, index) => ({ char, originalIndex: index }));

  const catalaDictionary = [
    { cat: /\bso\b/g, eng: 's' },
    { cat: /\bllibreria\b/g, eng: 'await samples' },
    { cat: /\bsoundfonts\b/g, eng: 'await soundfonts' },
    { cat: /\bantics\b/g, eng: "'github:tidalcycles/Dirt-Samples'" },
    { cat: /\bgm_synth\b/g, eng: "'github:joelmatthys/GM-synth'" },
    { cat: /\binstrument\b/g, eng: 's' },
    { cat: /\bnota\b/g, eng: 'note' },
    { cat: /\bnotes\b/g, eng: 'note' },
    { cat: /\btria\b/g, eng: 'choose' },
    { cat: /\bcapes\b/g, eng: 'stack' },
    { cat: /\.ràpid\b/g, eng: '.fast' },
    { cat: /\.lent\b/g, eng: '.slow' },
    { cat: /\.escala\b/g, eng: '.scale' },
    { cat: /\.ress(?:ò|o)(?!\w)/g, eng: '.room' },
    { cat: /\.reverb\b/g, eng: '.room' },
    { cat: /\.barreja\b/g, eng: '.shuffle' },
    { cat: /\.inversa\b/g, eng: '.rev' },
    { cat: /\.rev(?:é|e)s\b/g, eng: '.rev' },
    { cat: /\.panorama\b/g, eng: '.pan' },
    { cat: /\.banc\b/g, eng: '.bank' },
    { cat: /\.filtreGreus\b/g, eng: '.lpf' },
    { cat: /\.filtreAguts\b/g, eng: '.hpf' },
    { cat: /\.eco\b/g, eng: '.delay' },
    { cat: /\.8bit\b/g, eng: '.crush' },
    { cat: /\.distorsi[oó](?!\w)/g, eng: '.distort' },
    { cat: /\.volum\b/g, eng: '.gain' },
    { cat: /\.cada\b/g, eng: '.every' },
    { cat: /\.sovint\b/g, eng: '.sometimes' },
    { cat: /\.deVegades\b/g, eng: '.sometimes' },
    { cat: /\.moltSovint\b/g, eng: '.often' },
    { cat: /\.rarament\b/g, eng: '.rarely' },
    { cat: /\bbombo\b/g, eng: 'bd' },
    { cat: /\bcaixa\b/g, eng: 'sd' },
    { cat: /\bxarles\b/g, eng: 'hh' },
    { cat: /\bobert\b/g, eng: 'ho' },
    { cat: /\bpalmes\b/g, eng: 'cp' },
    { cat: /\bplateret\b/g, eng: 'cr' },
    { cat: /\btomagut\b/g, eng: 'ht' },
    { cat: /\btommig\b/g, eng: 'mt' },
    { cat: /\btomgreu\b/g, eng: 'lt' },
    { cat: /\bserra\b/g, eng: 'sawtooth' },
    { cat: /\bsinusoide\b/g, eng: 'sine' },
    { cat: /\bquadrat\b/g, eng: 'square' },
    { cat: /\btriangle\b/g, eng: 'triangle' },
    { cat: /\bbaix\b/g, eng: 'bass' },
    { cat: /(?<![a-zA-Z])do(?![a-zA-Z])/g, eng: 'c' },
    { cat: /(?<![a-zA-Z])re(?![a-zA-Z])/g, eng: 'd' },
    { cat: /(?<![a-zA-Z])mi(?![a-zA-Z])/g, eng: 'e' },
    { cat: /(?<![a-zA-Z])fa(?![a-zA-Z])/g, eng: 'f' },
    { cat: /(?<![a-zA-Z])sol(?![a-zA-Z])/g, eng: 'g' },
    { cat: /(?<![a-zA-Z])la(?![a-zA-Z])/g, eng: 'a' },
    { cat: /(?<![a-zA-Z])si(?![a-zA-Z])/g, eng: 'b' },
    { cat: /(?<![a-zA-Z])menor(?![a-zA-Z])/g, eng: 'minor' },
    { cat: /(?<![a-zA-Z])major(?![a-zA-Z])/g, eng: 'major' },
    { cat: /\bbpm\b/g, eng: '((c)=>setcpm(c/4))' },
  ];

  catalaDictionary.forEach((pair) => {
    replaceMapped(mappedChars, pair.cat, pair.eng);
  });

  const translatedText = mappedChars.map((mc) => mc.char).join('');
  return { translatedText, mappedChars };
}

export const AonEditor: React.FC<{ 
  code: string; 
  key?: string; 
  readOnly?: boolean;
  exercise?: {
    successMessage?: string;
    onCheck: (code: string) => { success: boolean; message: string };
  }
}> = ({ code, readOnly, exercise }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const editorNode = useRef<any>(null);
  const [checkResult, setCheckResult] = useState<{success: boolean; message: string} | null>(null);

  const [isPatched, setIsPatched] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      const editorEl = containerRef.current?.querySelector('strudel-editor') as any;
      if (editorEl && editorEl.editor && editorEl.editor.view) {
        editorNode.current = editorEl;
        
        const strudelMirror = editorEl.editor;
        if (!strudelMirror._patchedForCatalan && strudelMirror.repl) {
          const originalReplEvaluate = strudelMirror.repl.evaluate.bind(strudelMirror.repl);
          strudelMirror.repl.evaluate = async function(codeToEvaluate: string, autostart = true) {
            const { translatedText, mappedChars } = translateCodeAndGetMap(codeToEvaluate);
            strudelMirror._lastMapping = { mappedChars, originalLen: codeToEvaluate.length };
            try {
              return await originalReplEvaluate(translatedText, autostart);
            } catch (err: any) {
              throw err;
            }
          };

          const originalEvaluate = strudelMirror.evaluate.bind(strudelMirror);
          strudelMirror.evaluate = async function(autostart = true) {
            if (this.flash) {
              try { this.flash(); } catch (e) {}
            }
            return await this.repl.evaluate(this.code, autostart);
          };

          // Patch the CodeMirror view dispatch function to reverse-map index positions
          if (strudelMirror.view && !strudelMirror.view._dispatchPatched) {
            const originalDispatch = strudelMirror.view.dispatch;
            strudelMirror.view.dispatch = function(...args: any[]) {
              const mapping = strudelMirror._lastMapping;
              if (mapping) {
                for (const arg of args) {
                  if (arg && arg.effects) {
                    const effects = Array.isArray(arg.effects) ? arg.effects : [arg.effects];
                    for (const effect of effects) {
                      if (effect && effect.value) {
                        try {
                          // 1. setMiniLocations: array of [start, end]
                          if (
                            Array.isArray(effect.value) &&
                            effect.value.length > 0 &&
                            Array.isArray(effect.value[0]) &&
                            effect.value[0].length === 2
                          ) {
                            effect.value = effect.value.map(([start, end]: [number, number]) => {
                              const mappedStart = mapping.mappedChars[start]?.originalIndex ?? mapping.originalLen;
                              const mappedEnd = end > 0 ? (mapping.mappedChars[end - 1]?.originalIndex ?? mapping.originalLen) + 1 : mapping.originalLen;
                              return [mappedStart, mappedEnd];
                            });
                          }
                          // 2. showMiniLocations: object with haps containing whole.context.locations
                          else if (effect.value.haps) {
                            for (const hap of effect.value.haps) {
                              if (hap && hap.context && hap.context.locations) {
                                hap.context.locations = hap.context.locations.map(({ start, end }: { start: number; end: number }) => {
                                  const mappedStart = mapping.mappedChars[start]?.originalIndex ?? mapping.originalLen;
                                  const mappedEnd = end > 0 ? (mapping.mappedChars[end - 1]?.originalIndex ?? mapping.originalLen) + 1 : mapping.originalLen;
                                  return { start: mappedStart, end: mappedEnd };
                                });
                              }
                            }
                          }
                        } catch (e) {
                          console.warn('Error patching miniLocation effect', e);
                        }
                      }
                    }
                  }
                }
              }
              return originalDispatch.apply(this, args);
            };
            strudelMirror.view._dispatchPatched = true;
          }

          strudelMirror._patchedForCatalan = true;
          clearInterval(timer);
          setIsPatched(true);
        }
      }
    }, 100);

    return () => {
      clearInterval(timer);
      const editorEl = editorNode.current || containerRef.current?.querySelector('strudel-editor') as any;
      if (editorEl && editorEl.editor) {
        try {
          editorEl.editor.stop();
        } catch (e) {
          console.warn('Error stopping on unmount', e);
        }
      }
    };
  }, []);

  useEffect(() => {
    if (isPatched && containerRef.current) {
      const editorEl = containerRef.current.querySelector('strudel-editor') as any;
      if (editorEl) {
        editorEl.setAttribute('code', code);
        
        if (editorEl.getAttribute('data-prebake-handled') !== 'true') {
          editorEl.setAttribute('data-prebake-handled', 'true');
          if (code && code.trim()) {
            if (editorEl.editor && typeof editorEl.editor.evaluate === 'function') {
              editorEl.editor.evaluate(false).catch((e: any) => console.log('initial eval err:', e));
            }
          }
        }
      }
    }
  }, [code, isPatched]);

  const getEditorEl = () => {
    if (editorNode.current) return editorNode.current;
    if (containerRef.current) {
      const editorEl = containerRef.current.querySelector('strudel-editor') as any;
      if (editorEl && editorEl.editor) {
        editorNode.current = editorEl;
        return editorEl;
      }
    }
    return null;
  };

  const handlePlay = () => {
    const editorEl = getEditorEl();
    if (editorEl && editorEl.editor) {
      const currentCode = editorEl.editor.code || editorEl.code || "";
      if (!currentCode.trim()) {
        try {
          editorEl.editor.stop();
        } catch (e) {
          console.error(e);
        }
        setIsPlaying(false);
        return;
      }
      try {
        editorEl.editor.evaluate();
      } catch (e) {
        console.error(e);
      }
      setIsPlaying(true);
    }
  };

  const handleStop = () => {
    const editorEl = getEditorEl();
    if (editorEl && editorEl.editor) {
      try {
        editorEl.editor.stop();
      } catch (e) {
        console.error(e);
      }
      setIsPlaying(false);
    }
  };

  const handleCheck = () => {
    const editorEl = getEditorEl();
    if (editorEl && exercise) {
      const currentCode = editorEl.editor.code || editorEl.code || "";
      const result = exercise.onCheck(currentCode);
      if (result.success && exercise.successMessage) {
        setCheckResult({ success: true, message: exercise.successMessage });
      } else {
        setCheckResult(result);
      }
    }
  };

  return (
    <div className="w-full h-full overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm flex flex-col relative" style={{ minHeight: '600px' }} ref={containerRef}>
      
      {/* Tools Bar */}
      <div className="h-14 border-b border-slate-200 bg-slate-50 flex items-center px-4 gap-3 relative z-20 flex-shrink-0">
        <button 
          onClick={handlePlay}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-white font-bold tracking-wide transition-all shadow-sm active:scale-95 cursor-pointer ${
            isPlaying ? 'bg-emerald-600 ring-2 ring-emerald-300 animate-pulse' : 'bg-emerald-500 hover:bg-emerald-600'
          }`}
        >
          <Play size={16} fill="currentColor" />
          {isPlaying ? 'Reproduint...' : 'Reprodueix'}
        </button>

        <button 
          onClick={handleStop}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-white font-bold tracking-wide transition-colors shadow-sm active:scale-95 cursor-pointer ${
            isPlaying ? 'bg-rose-500 hover:bg-rose-600' : 'bg-slate-400 hover:bg-slate-500'
          }`}
        >
          <Square size={16} fill="currentColor" />Atura</button>

        {exercise && (
          <button 
            onClick={handleCheck}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold tracking-wide transition-colors shadow-sm active:scale-95 cursor-pointer"
          >
            <Check size={16} fill="currentColor" />
            Validar codi
          </button>
        )}
        
        <div className="text-sm font-semibold text-slate-500 ml-auto hidden sm:block">
          Modifica el codi a sota i prem Play
        </div>
      </div>


      {/* Editor Content */}
      <div className={`flex-1 relative overflow-hidden flex flex-col min-h-[400px] ${readOnly ? 'pointer-events-none opacity-90' : 'bg-white'}`}>
        {/* @ts-ignore */}
        <strudel-editor></strudel-editor>

        {checkResult && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-lg">
             <div className={`p-4 rounded-xl flex items-start gap-3 shadow-lg shadow-black/10 border ${
               checkResult.success 
                 ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                 : 'bg-violet-50 border-violet-200 text-violet-800'
             }`}>
               {checkResult.success ? <CheckCircle2 className="text-emerald-500 shrink-0" /> : <XCircle className="text-violet-500 shrink-0" />}
               <div className="flex-1">
                 <p className="text-sm font-medium leading-relaxed">{checkResult.message}</p>
                 <button onClick={() => setCheckResult(null)} className="text-xs mt-2 underline opacity-70 hover:opacity-100">
                   {checkResult.success ? 'Continuar' : 'Tancar i provar de nou'}
                 </button>
               </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
}
