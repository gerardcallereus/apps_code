import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_6_1_efectes_exercici: Lesson = {
    id: '6.1-efectes-exercici',
    title: "7.1 Exercici d'Espais",
    icon: Target,
    content: () => (
      <div className="space-y-4">
        <p className="text-lg text-slate-800 font-medium">Panoràmiques de pel·lícula i Atmosferes deep</p>
        <p className="text-slate-600">
          Controlar un so en obertures altes requereix dominar el panorama i l'estat reverberant de tota la pista. Això s'aplica especialment a les notes Sinusoide i als Pads Ambientals del House.
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">📝 Requisits:</h4>
          <ul className="list-disc pl-5 text-sm text-slate-700 font-medium marker:text-indigo-300 space-y-2">
            <li>Construeix un patró de <code>nota()</code> i aplica-hi directament l'efecte reverberant de càmera amb estat <code>.ressò(...)</code></li>
            <li>Defineix l'estèreo enviant les coordenades de canvi dins un String, exactament escrit d'aquesta manera per rebotar esquerra/mig/dreta: <code>.panorama("0 0.5 1")</code></li>
          </ul>
        </div>
      </div>
    ),
    initialCode: '',
    exercise: {
      successMessage: "Ho has completat de forma gloriosa! L'atmosfera s'apodera de l'espai.",
      onCheck: (code) => {
        const hasRoom = code.includes(".ressò(");
        const hasPanArray = code.includes(".panorama(\"0 0.5 1\")") || code.includes(".panorama('0 0.5 1')");
        
        if (!hasRoom) return { success: false, message: "Ens falta assignar ressonància amb el ressò() a l'efecte." };
        if (!hasPanArray) return { success: false, message: "El panorama ha de fer exactament 0 (esq), 0.5 (centre) i 1 (dreta) escrit entre cometes: .panorama(\"0 0.5 1\")" };
        
        return { success: true, message: "Perfecte! Estàs llest/a." };
      }
    }
};
