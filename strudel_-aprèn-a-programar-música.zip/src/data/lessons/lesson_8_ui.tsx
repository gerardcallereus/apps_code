import { MousePointer2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_8_ui: Lesson = {
  id: '8-modificadors-ui',
  title: '9. Modificadors Interactius (UI)',
  icon: MousePointer2,
  content: ({ setCode }) => (
    <div className="space-y-5">
      <p>
        A més d'alterar paràmetres de forma totalment automatitzada via l'atzar, també podem tenir un <strong>control manual</strong> directe des de la pantalla sobre els paràmetres utilitzant elements visuals que generen una interfície d'usuari interactiva de sobretaula (UI).
      </p>

      <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-4 font-display flex gap-2 items-center">🎛️ Modificadors i Sliders</h3>
        
        <div className="space-y-4">
          <div>
            <p className="font-bold text-slate-900 border-b border-slate-200 pb-1 mb-2 font-sans text-xs uppercase tracking-wider">Els Sliders a l'Aon</p>
            <p className="text-sm text-slate-600 mb-2 leading-relaxed font-medium">
              Si vols distribuir o "pannejar" de dreta a esquerra segons el que vulguis en directe, o tallar un filtre, pots incorporar la funció <code className="bg-slate-100 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] border border-slate-200">slider(valorInicial, mínim, màxim)</code>. Per exemple, pots establir límits de la següent manera: <code className="bg-slate-100 px-1 font-mono text-[13px] rounded">slider(0, -1, 1)</code> crearia un slider que va de -1 a 1 (començant a 0), o amb altres rangs de freqüències.
            </p>
            <CodeBox 
              setCode={setCode} 
              description="Sona seqüencial. Surt de l'editor i observa una nova pestanya sota ell permetent moure manualment on vols situar en freqüència i panorama aquest seqüenciador:"
              code={'bpm(120)\n\nnota("0 2").escala("mi:menor").instrument("serra").ràpid(2)\n  .panorama(slider(0, -1, 1))\n  .filtreGreus(slider(1500, 400, 3000))'} 
            />
          </div>

          <div className="pt-2">
            <p className="font-bold text-slate-900 border-b border-slate-200 pb-1 mb-2 font-sans text-xs uppercase tracking-wider">El Piano Roll (_pianoroll)</p>
            <p className="text-sm text-slate-600 mb-2 leading-relaxed font-medium">
              Si el que vols és simplement analitzar en pantalla allò per desenvolupadors sense afegir una interactuació manual externa al soroll, pots encadenar <code className="bg-slate-100 px-1 font-mono text-[13px] text-rose-600 rounded">._pianoroll()</code> al darrer de tot de la pista. Obrirà de seguida una quadrícula visual mostrant les notes al moment conforme es reprodueixen. És la forma més eficaç d'entendre al vol on corren les melodies en escala temporal!
            </p>
            <CodeBox 
              setCode={setCode} 
              description="Llança aquest arpegio i gaudeix d'una gràfica representativa just a sota de l'editor marcant exactament on apareixen:"
              code={'bpm(120)\n\nnota("0 [3 5] 7 [~ 10]").escala("do:menor").instrument("serra").ràpid(2)._pianoroll()'} 
            />
          </div>
        </div>
      </div>
    </div>
  ),
  initialCode: ''
};
