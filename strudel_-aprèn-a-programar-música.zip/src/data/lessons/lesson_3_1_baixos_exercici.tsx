import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_3_1_baixos_exercici: Lesson = {
    id: '3.1-baixos-exercici',
    title: '4.1 Exercici de Baixos numèrics',
    icon: Target,
    content: () => (
      <div className="space-y-4">
        <p className="text-lg text-slate-800 font-medium">Bases Sòlides en Escala</p>
        <p className="text-slate-600">
          Crea el teu primer baix fent servir l'instrument `triangle`, silencis `~` i el mètode d'escales.
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">📝 Requisits:</h4>
          <ul className="list-disc pl-5 text-sm text-slate-700 font-medium marker:text-indigo-300 space-y-2">
            <li>Utilitza el mètode <code>nota()</code> per escriure un patró només amb números i almenys un silenci <code>~</code>.</li>
            <li>Afegeix l'escala musical: <code>.escala("do:menor")</code> o la clau que més t'agradi.</li>
            <li>Afegeix sempre l'instrument: <code>.instrument("triangle")</code>.</li>
          </ul>
        </div>
      </div>
    ),
    initialCode: '',
    exercise: {
      successMessage: "Perfecte! Ara tens la clau per compondre de forma professional i sense desafinar mai.",
      onCheck: (code) => {
        const hasNType = code.includes("nota(");
        const hasTriangle = code.includes("triangle");
        const hasSilenci = code.includes("~");
        const hasScale = code.includes(".escala(");
        
        if (!hasNType) return { success: false, message: 'La instrucció per donar números al baix (nota("...")) no hi és.' };
        if (!hasScale) return { success: false, message: 'Has de cridar .escala("...") per fixar la tonalitat!' };
        if (!hasTriangle) return { success: false, message: 'Ens falta indicar l\'instrument .instrument("triangle")' };
        if (!hasSilenci) return { success: false, message: 'Has de posar com a mínim un silenci ~ entre les notes numèriques!' };
        
        return { success: true, message: "Fantàstic! El groove hi és present." };
      }
    }
};
