import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_9_projecte_final: Lesson = {
    id: '11-projecte-final',
    title: '12. Disseny Lliure de Projecte Final',
    icon: Trophy,
    content: () => (
      <div className="space-y-4">
        <p className="text-lg text-slate-800 font-medium border-l-4 border-rose-400 pl-4 py-1">
          L'arquitectura musical i sintàctica l'has superat amb nota, has arribat al final del camí guiat. És l'hora del projecte sense xarxes de contenció. 🚀
        </p>
        
        <p>
          Ara l'escenari és completament teu! Dissenya la teva cançó final, escull el teu gènere (Acid, Techno, House, Trance o Ambient). Al teu editor tens el full en blanc pràcticament net, però ple de recomanacions en comentaris. Pensa en un ritme principal constant, un baix que s'alterni per darrera com a suport, i un bon sintetitzador per liderar.
        </p>
        
        <p>Afegeix <code>.sovint</code> i filtres per textura, i llança-les al ritme dins de <code>capes</code>. Et converteixes oficialment en un Mestre Live Coder de bateries textuals.</p>

        <div className="mt-8 p-5 rounded-2xl bg-amber-50/50 border border-amber-200 shadow-sm shadow-amber-100/50">
          <h3 className="text-xs font-bold text-amber-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🏆 Demostra el Talent en Live:</h3>
          <p className="text-sm text-slate-600 font-medium">Programa en directe. Reprodueix. Modifica el codi sense que baixi la intensitat gràcies a l'Aon! Recorda que en qualsevol moment pots mirar enrere a tot l'abast d'aquest menú a l'esquerra per recordar els detalls sintàctics de l'Eina de Programació Web. Ens veiem als escenaris.</p>
        </div>
      </div>
    ),
    initialCode: ''
};
