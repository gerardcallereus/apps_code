import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_0_intro: Lesson = {
    id: '0-intro',
    title: '0. Benvinguda',
    icon: Sparkles,
    isReadOnly: true,
    content: () => (
      <div className="space-y-4">
        <h2 className="text-3xl font-display font-bold text-slate-800 tracking-tight">Benvingut/da a l'Aon</h2>
        <p className="text-lg text-slate-600 font-medium leading-relaxed">
          Aon és una eina que ens permet fer música escrivint codi (el que s'anomena <em>Live Coding</em>). Darrere d'aquesta simple idea s'amaga tot un univers on la programació es troba amb l'art.
        </p>
        <p className="text-slate-600 leading-relaxed">
          Pots programar estructures complexes, canviar ritmes en directe actuant (per això s'anomena "Live") i fer cançons senceres que viuen, respiren i evolucionen autònomament. Al costat dret veuràs una part d'aquesta gran obra: un <strong>Melodic Techno</strong> creat únicament amb text pur i dur.
        </p>
        <div className="mt-8 p-6 rounded-2xl bg-gradient-to-br from-indigo-50 to-rose-50 border border-indigo-100/50 shadow-sm shadow-indigo-100/30">
          <h3 className="text-xs font-bold text-indigo-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎧 Gaudeix de l'espectacle:</h3>
          <p className="text-sm text-slate-700 font-medium">Fes clic al botó verd de <strong>Play</strong> dins de l'editor de la dreta i observa com ballen els visualitzadors de ritme.</p>
        </div>
      </div>
    ),
    initialCode: `bpm(124)

/* ============================
    AON MOTOR - MELODIC TECHNO
   ============================ */

const kick   = so("bombo*4")
const hats   = so("~ xarles").ràpid(2)
const claps  = so("~ palmes")
const glitch = so("perc").ràpid(4).sovint(x => x.lent(2))

const bateria = capes(kick, hats, claps, glitch)

const baix = nota("do3 ~ do3 mi3 ~ do3 fa3 ~")
  .escala("la:menor")
  .instrument("triangle")
  .filtreGreus(400)

const melodia = nota("~ do4 mi4 sol4 ~ mi4 la4 do5")
  .escala("la:menor")
  .instrument("serra")
  .filtreGreus(1500)
  .ressò(0.7)

const pad = nota("la3")
  .instrument("sinusoide")
  .barreja(2)
  .ressò(0.9)
  .lent(2)

capes(
  bateria,
  baix,
  melodia,
  pad
)`
};
