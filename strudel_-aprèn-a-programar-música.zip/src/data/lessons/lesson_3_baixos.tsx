import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_3_baixos: Lesson = {
    id: '3-baixos',
    title: '4. Afegir un Baix',
    icon: Music,
    content: ({ setCode }) => (
      <div className="space-y-4">
        <p>
          Si abans fèiem percussió, ara farem melodies! I la capa més profunda que dóna pes a qualsevol cançó és el baix.
        </p>
        <p>
          Utilitzarem la instrucció <code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">nota()</code> per escriure notes musicals en comptes de percussions. Després indicarem l'instrument amb <code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">.instrument()</code>.
        </p>
        
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50 pointer-events-none">
          <h4 className="text-indigo-600 text-xs font-bold uppercase tracking-wider mb-3 font-display flex gap-2 items-center">📝 Notació Musical</h4>
          <p className="text-sm text-slate-600 mb-3 font-medium">L'escriptura musical és literal! Utilitzem l'escala de notes do, re, mi, fa, sol, la i si. El número al costat de la nota (ex: <code className="font-mono text-rose-500 bg-rose-50 px-0.5 rounded">do3</code>) indica l'octava (més baix o més agut).</p>
        </div>
        
        <CodeBox 
          setCode={setCode} 
          description="Provem un baix amb molt més groove i misteri fent servir l'instrument quadrat:"
          code={'bpm(120)\n\nnota("la2 do3 mi3 la3 do3 ~ la2 ~").instrument("quadrat").ràpid(1.5)'} 
        />
        
        <p>
          Un altre baix molt potent és el <code className="font-mono text-rose-500 border rounded bg-rose-50 px-1 text-sm border-rose-200">triangle</code>. En aquest exemple afegirem silencis amb la tilde <code className="font-mono text-rose-500 border rounded bg-rose-50 px-1 text-sm border-rose-200">~</code> per crear espais que faran que la cançó respiri millor.
        </p>

        <CodeBox 
          setCode={setCode} 
          description="L'ús de ~ afegeix silencis temporals. A més, podem encadenar .ràpid() a la capa del baix!"
          code={'bpm(120)\n\nnota("do2 ~ re2 ~ do2 fa2").instrument("triangle").ràpid(2)'} 
        />

        <div className="bg-amber-50/50 border border-amber-100 p-5 my-6 rounded-2xl shadow-sm shadow-amber-100/50">
          <h4 className="text-amber-600 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎹 Treballant amb Escales Musicals</h4>
          <p className="text-sm text-slate-700 font-medium mb-3">
            Escriure manualment nota per nota (do2, re2, la2) pot ser lent i hi ha risc de sortir-nos de l'escala o clau musical (desafinar). A l'Aon, els professionals sovint fan servir números combinats amb <code>.escala()</code>. 
          </p>
          <ul className="list-disc pl-5 text-sm text-slate-700 mb-4 space-y-1">
            <li>El número <code className="font-mono bg-white px-1">0</code> és la nota principal de l'escala (tònica).</li>
            <li>El <code className="font-mono bg-white px-1">1</code> és la següent nota de l'escala, el <code className="font-mono bg-white px-1">2</code> la següent, etc.</li>
            <li>Si fem servir <code className="font-mono bg-white px-1">.escala("la:menor")</code>, Aon tradueix aquests números automàticament per a que sempre sonin dins d'aquella escala!</li>
          </ul>
          
          <CodeBox 
            setCode={setCode} 
            description="Fixa't: ja no fem servir 'nota()', sinó 'nota()' per introduir els números, i definim una escala per defecte com 'la:menor' (La menor). Serà impossible desafinar!"
            code={'nota("0 ~ 2 3 ~ -1 0 0").escala("la:menor").instrument("triangle").ràpid(2)'} 
          />
        </div>

        <div className="mt-8 p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 shadow-sm shadow-emerald-100/50">
          <h3 className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎯 Repte:</h3>
          <p className="text-sm text-slate-600 leading-relaxed font-medium">Carga l'últim exemple amb "nota()" i "escala()". Canvia el nom de l'escala de "la:menor" a "do:major" (Do major) o "sol:menor" (Sol menor). Escolta com tota la base de la cançó canvia de to màgicament mentre manté el mateix patró numèric de ritme!</p>
        </div>
      </div>
    ),
    initialCode: ''
};
