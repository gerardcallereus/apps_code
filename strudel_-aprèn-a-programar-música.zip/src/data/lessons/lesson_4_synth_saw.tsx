import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_4_synth_saw: Lesson = {
    id: '4-synth-saw',
    title: '5. Synths i Paràmetres',
    icon: ListMusic,
    content: ({ setCode }) => (
      <div className="space-y-4">
        <p>
          Continuem descobrint sintetitzadors per crear melodies electròniques. Un instrument pur electrònic ideal per arpegis ràpids i els clàssics sons d'<strong>Acid House i Acid Techno</strong> és el sintetitzador <code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">serra</code> (sawtooth). Aquest instrument produeix un so ric en harmònics, molt "esmolat".
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">💡 Conceptes de Programació: Paràmetres i Filtres</h4>
          <p className="text-sm text-slate-600 leading-relaxed font-medium">
            Així com <code>.ràpid(2)</code> demana un número per a accelerar, existeixen funcions com <code className="text-rose-600 font-semibold font-mono">.filtreGreus(800)</code>. El número que inserim entre els parèntesis és un <strong>Paràmetre</strong>. En aquest cas fa un "Low Pass Filter", demanant a l'instrument que talli tot so que superi els 800 hertz, deixant el synth molt menys "estrident". Modular aquest tall al llarg d'una cançó és la base del famós so **Àcid** (el plor i crits típics del sintetitzador Roland TB-303).
          </p>
        </div>
        
        <p className="mb-2">Dues funcions imprescindibles de texturització i variació:</p>
        <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-indigo-300">
          <li><code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">.filtreGreus(val)</code>: Talla freqüències per sobre de `val`. Valors útils van del 200 fins el 4000.</li>
          <li><code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">.barreja(N)</code>: Barreja l'ordre del patró! Si N és 2 jugarà aleatoritzant parts de la melodia constantment cada cop que es repeteix el cicle.</li>
        </ul>

        <CodeBox 
          setCode={setCode} 
          description="Aquesta melodia Àcida aplicada amb un filtreGreus(1000) suau, accelerada i amb l'ordre completament desordenat per barreja(2) mai sonarà igual dues vegades:"
          code={'bpm(135)\n\nnota("la2 do3 mi3 sol3 ~ la3 re3 ~").instrument("serra").filtreGreus(1000).ràpid(2).barreja(2)'} 
        />
        
        <div className="mt-8 p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 shadow-sm shadow-emerald-100/50">
          <h3 className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎯 Repte: Crea l'Acid Bass</h3>
          <p className="text-sm text-slate-600 leading-loose font-medium">
            Obre el codi superior i canvia el valor de `filtreGreus` a xifres com `400` i notaràs com s'enfosqueix creant el mític "squelch" de l'Acid House. Després canvia-ho a `3000` i despertaràs una línia Techno agressiva impressionant!
          </p>
        </div>
      </div>
    ),
    initialCode: ''
};
