import React from 'react';
import { Target } from 'lucide-react';
import { Lesson } from '../../types';

export const lesson_2_6_bpm_exercici: Lesson = {
    id: '2.6-bpm-exercici',
    title: '3.1 Exercici: Fes-ho Ràpid!',
    icon: Target,
    content: () => (
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800 mb-3 tracking-tight font-display">Alça els BPMs</h2>
          <p className="text-slate-600 leading-relaxed font-medium">
            T'hem preparat un petit bucle, però requereix una velocitat molt més enèrgica. 
            Afegeix la instrucció <code>bpm()</code> a la primera línia i fixa la velocitat de la cançó a <strong>150</strong> batecs per minut.
          </p>
        </div>
      </div>
    ),
    initialCode: '',
    exercise: {
      successMessage: "Wow, això va molt ràpid! Has controlat el tempo.",
      onCheck: (code) => {
        const hasBPM = code.includes("bpm(");
        const has150 = code.includes("150");
        
        if (!hasBPM) {
          return { success: false, message: 'No veic la instrucció per definir els bpm().' };
        }
        
        if (!has150) {
          return { success: false, message: 'Assegura\'t de posar exactament 150 dins els parèntesis: bpm(150)' };
        }

        return { success: true, message: 'Perfecte! El tempo s\'ha actualitzat.' };
      }
    }
};
