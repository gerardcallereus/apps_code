import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_5_1_synth_sine_exercici: Lesson = {
    id: '5.1-synth-sine-exercici',
    title: '6.1 Exercici Atzar',
    icon: Target,
    content: () => (
      <div className="space-y-4">
        <p className="text-lg text-slate-800 font-medium">Tirant els daus</p>
        <p className="text-slate-600">
          La gràcia de programar música electrònica no és reproduir sempre la mateixa escala monòtona. Dona-li un toc màgic amb "Callbacks" probabilístics!
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">📝 Requisits:</h4>
          <ul className="list-disc pl-5 text-sm text-slate-700 font-medium marker:text-indigo-300 space-y-2">
            <li>Utilitza el mètode d'atzar <code>.sovint()</code> sobre aquesta freqüència suau (pista sinusoide).</li>
            <li>Envia-li una funció fletxa com a callback al seu interior: per exemple: <code>x =&gt; x.inversa()</code>.</li>
          </ul>
        </div>
      </div>
    ),
    initialCode: '',
    exercise: {
      successMessage: "L'atzar ara està sota el teu control. Estàs dotant les seqüències de vida intel·ligent!",
      onCheck: (code) => {
        const hasSometimes = code.includes(".sovint(");
        const hasArrow = code.includes("=>") || code.includes("x=");
        
        if (!hasSometimes) return { success: false, message: "Afegeix l'efecte sovint() a alguna melodia i passa-li els paràmetres!" };
        if (!hasArrow) return { success: false, message: "Falta la notació fletxa! ('x => x.inversa()') per explicar com ha d'interactuar l'atzar del sovint() sobre el conjunt x (el patró original)." };
        
        return { success: true, message: "Genial! Callbacks llistes." };
      }
    }
};
