import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_5_synth_sine: Lesson = {
    id: '5-synth-sine',
    title: '6. Synths Suaus i Atzar',
    icon: AudioLines,
    content: ({ setCode }) => (
      <div className="space-y-4">
        <p>
          L'instrument <code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">sinusoide</code> (sine) crea melodies molt dolces i ambientals, idees per a línies d'acords Deep House i Trance vocal. Consisteix en una ona de sintesis sinusoïdal perfecta, el to pur sense harmònics extres! A més a més, ens servirà per veure com introduir <strong>l'atzar informàtic</strong>.
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">💡 Conceptes de Programació: Callbacks i Atzar</h4>
          <p className="text-sm text-slate-600 leading-relaxed font-medium">
            En la programació avançada podem dir-li a una funció que n'utilitzi una altra només "de vegades" (probabilitat). La funció <code className="text-rose-600 font-semibold font-mono">.sovint(...)</code> llença un dau internament; si el resultat és veritat, llegeix el text que hem ficat dintre, com ara <code className="text-rose-600 font-semibold font-mono">x =&gt; x.inversa()</code>. Aqueta notació de fletxa vol dir literalment: "La pista X serà llegida utilitzant el mètode X.inversa() (reverse)".
          </p>
        </div>
        <ul className="list-disc pl-5 space-y-2 marker:text-indigo-300">
          <li><code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">.sovint(x =&gt; x.ràpid(2))</code>: En moments a l'atzar, aquesta pista anirà el doble de ràpid.</li>
          <li><code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">.sovint(x =&gt; x.inversa())</code>: En moments a l'atzar, reproduirà les notes en ordre invertit.</li>
        </ul>

        <CodeBox 
          setCode={setCode} 
          description="Escolta aquesta preciosa melodia ascendent. A causa del .sovint(x => x.inversa()), sovint la sentiràs reproduir-se màgicament al revés, de dreta a esquerra!"
          code={'bpm(125)\n\nnota("mi4 sol4 la4 do5").instrument("sinusoide").sovint(x => x.inversa())'} 
        />
        
        <CodeBox 
          setCode={setCode} 
          description="Això arpegia un patró melangiós per defecte en xarxa de ràpid 2... però salta esporàdicament a triplicar-se! Això crearà patrons orgànics."
          code={'bpm(125)\n\nnota("la4 do4 mi4 la4").instrument("sinusoide").ràpid(2).sovint(x => x.ràpid(3))'} 
        />

        <div className="mt-8 p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 shadow-sm shadow-emerald-100/50">
          <h3 className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎯 Repte:</h3>
          <p className="text-sm text-slate-600 leading-loose font-medium">
            Esbrina com modificar el mètode després de la fletxa <code>x.</code> del primer exemple i prova d'ajuntar-hi <code>barreja(2)</code> o el que et vingui de gust!
          </p>
        </div>
      </div>
    ),
    initialCode: ''
};
