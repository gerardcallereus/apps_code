import { Sparkles } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_7_caos: Lesson = {
  id: '7-caos-controlat',
  title: '8. Caos Controlat (Funcions de codi)',
  icon: Sparkles,
  content: ({ setCode }) => (
    <div className="space-y-5">
      <p>
        El veritable poder del live coding és deixar que el navegador prengui decisions per tu, però sempre <strong>sota les teves regles</strong>. Pots utilitzar funcions que canvien la música de forma dinàmica en cada cicle per generar patrons impredictibles.
      </p>

      <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-4 font-display flex gap-2 items-center">
          🎲 Eines d'Aleatorietat
        </h3>
        
        <div className="space-y-4">
          <div>
            <p className="font-bold text-slate-900 border-b border-slate-200 pb-1 mb-2 font-sans text-xs uppercase tracking-wider">Aleatorietat Contínua (rand)</p>
            <p className="text-sm text-slate-600 mb-2 leading-relaxed font-medium">
              En lloc de deixar valors com el panoràmic o el filtre estàtics, <code className="bg-slate-100 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] border border-slate-200">rand</code> genera un valor nou entre 0 i 1 constantment. Això és perfecte per fer que cada cop del sintetitzador salti a un lloc diferent de forma salvatge.
            </p>
            <CodeBox 
              setCode={setCode} 
              description="Aplica 'rand' al paràmetre del panoràmic perquè cada nota soni erràticament per l'esquerra o per la dreta a l'atzar."
              code={'bpm(120)\n\nnota("0 2 4 7").escala("do:major").instrument("serra").panorama(rand).ràpid(2)'} 
            />
          </div>

          <div className="pt-2">
            <p className="font-bold text-slate-900 border-b border-slate-200 pb-1 mb-2 font-sans text-xs uppercase tracking-wider">Opcions Tancades (choose)</p>
            <p className="text-sm text-slate-600 mb-2 leading-relaxed font-medium">
              Et permet donar-li al codi una llista tancada (<code className="bg-slate-100 text-rose-600 px-1.5 py-0.5 rounded-md text-[13px] border border-slate-200 font-mono">tria(1, 2, 3)</code>). Aon triarà a l'atzar, però només entre aquestes opcions. Assegura que el caos sempre soni harmònic, dints dels límits que defineixes.
            </p>
            <CodeBox 
              setCode={setCode} 
              description="Fica totes les teves combinacions bones i deixa que la màquina creï la melodia escollint aleatòriament els teus números:"
              code={'bpm(120)\n\nnota(tria(0, 3, 5, 7, 10, 12)).escala("do:menor").instrument("quadrat").ràpid(4)'} 
            />
          </div>

          <div className="pt-2">
            <p className="font-bold text-slate-900 border-b border-slate-200 pb-1 mb-2 font-sans text-xs uppercase tracking-wider">Probabilitats (sometimes, often, rarely)</p>
            <p className="text-sm text-slate-600 mb-2 leading-relaxed font-medium">
              A la lliçó de <strong>Callbacks</strong> ja vas veure <code className="bg-slate-100 px-1 font-mono text-sm rounded">sovint()</code>. Ara afegim-hi <code className="bg-slate-100 px-1 font-mono text-sm rounded">moltSovint()</code> i <code className="bg-slate-100 px-1 font-mono text-sm rounded">rarament()</code>. Aquestes funcions permeten alterar certes frases de pas, ideal per trencar la monotonia, per exemple, pujar octaves o tallar filtres però només de tant en tant, aportant un patró de bateria ple de variació.
            </p>
            <CodeBox 
              setCode={setCode} 
              description="Fes el patró més atzarós amb modificadors funcionant sota diferents probabilitats combinades:"
              code={'bpm(120)\n\nso("bombo xarles caixa xarles").ràpid(2)\n  .sovint(x => x.ràpid(2)) // A vegades el doble de ràpid\n  .rarament(x => x.inversa())      // Rarament invertit\n  .moltSovint(x => x.filtreGreus(1000))   // Molt sovint enfosquit'} 
            />
          </div>
        </div>
      </div>
    </div>
  ),
  initialCode: ''
};
