import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_7_combinar: Lesson = {
    id: '9-combinar',
    title: '10. Variables i Capes',
    icon: AudioLines,
    content: ({ setCode }) => (
      <div className="space-y-4">
        <p>
          Si has arribat fins aquí, domines bateries, baixos, synths d'agressió (serra - Acid) i els de tranquil·litat espacial (sinusoide - Deep/Trance). Ha arribat el moment de posar cada instrument i fondre'ls entre si construïnt l'esquelet central d'una cançó sencera: <strong>La Superposició Multicapa i l'ús de Variables en JavaScript.</strong>
        </p>

        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">💡 Conceptes de Programació: Variables i "capes"</h4>
          <p className="text-sm text-slate-600 leading-relaxed font-medium">
            En programació de debò, per no escriure un codi quilomètric de text difícil de seguir, assignem totes les frases a noms clau anomenades "Variables". Fem servir la declaració <code className="text-rose-600 font-semibold font-mono">const bateria = so("bombo caixa")</code>. Més avall fem el mateix pel baix: <code className="text-rose-600 font-semibold font-mono">const baix = nota("do3...</code>.<br /> I el cor musical és la funció englobadora multipista <code className="text-rose-600 font-semibold font-mono">capes(bateria, baix)</code> que els executarà temporalment superposats!!
          </p>
        </div>

        <CodeBox 
          setCode={setCode} 
          description="Fixa't en aquesta estructura neta de House. Hem donat espai a cada part individualment, abans de vincular-ho al final exactament en la funció 'capes'."
          code={'bpm(125)\n\nconst bateria = so("bombo xarles bombo [caixa xarles]").ràpid(2)\nconst baix = nota("do3 ~ mi3 fa3").instrument("triangle").ràpid(2)\n\ncapes(\n  bateria,\n  baix\n)'} 
        />

        <div className="mt-8 p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 shadow-sm shadow-emerald-100/50">
          <h3 className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎯 Repte:</h3>
          <p className="text-sm text-slate-600 leading-loose font-medium">
            Actua com un vertader DJ de House: mentre la pista estigui reproduint-se a l'editor lateral tanca l'entrada esborrant temporalment paràmetres com el 'baix' de dins l'stack i torna-lo a posar un parell de temps musicals després. Veus com pot ser de útil quan actues en viu en una Live session?
          </p>
        </div>
      </div>
    ),
    initialCode: ''
};
