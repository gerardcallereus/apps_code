import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_2_sequencies: Lesson = {
    id: '2-sequencies',
    title: '2. Ritmes (Seqüències)',
    icon: AudioLines,
    content: ({ setCode }) => (
      <div className="space-y-4">
        <p>
          Un patró format per diversos passos s'anomena <strong>seqüència</strong> (sequence). Ens serveixen per donar el toc d'estil i repetició que tenen precisament tots els ritmes de les teves cançons preferides.
        </p>
        
        <div className="bg-amber-50/50 border border-amber-100 p-5 my-6 rounded-2xl shadow-sm shadow-amber-100/50">
          <h3 className="text-amber-600 text-sm font-bold flex gap-2 items-center mb-3">
            <span className="text-lg">⏱️</span> El Cicle de Temps (Cicles vs Passos)
          </h3>
          <p className="text-slate-700 text-sm mb-4">
            A l'Aon, el concepte fonamental és el <strong>cicle</strong>. Un patró complet triga **exactament 1 cicle** en reproduir-se, indiferentment de quants passos (notes) hi posis a dins. Reprodueix aquests 3 patrons lentament al teu editor i comprova al costat de cada codi aquesta diferència de velocitat en encabir més notes:
          </p>
          <div className="space-y-4">
            <CodeBox 
              setCode={setCode} 
              description="(2 passos) triga 1 cicle. Van a un ritme moderat i omplen la meitat d'espectre cadascun:"
              code={'so("bombo caixa")'} 
            />
            <CodeBox 
              setCode={setCode} 
              description="(4 passos) triga 1 cicle. Han d'anar el doble de ràpids per encaixar tots 4 a dins!"
              code={'so("bombo caixa xarles bombo")'} 
            />
            <CodeBox 
              setCode={setCode} 
              description="(8 passos) triga 1 cicle. Com hi ha molts passos encabits en el mateix temps de cicle, aniran més ràpids encara!"
              code={'so("bombo xarles xarles xarles xarles xarles xarles xarles")'} 
            />
          </div>
        </div>

        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">💡 Conceptes de Programació: Subdivisions per ritmes TECHNO / TRANCE</h4>
          <p className="text-sm text-slate-600 leading-relaxed font-medium">
            Molt més útil que atapeir la seqüència general amb elements, podem subdividir alguns d'aquests passos utilitzant els claudàtors <code className="text-rose-600 font-semibold font-mono">[ ]</code>. En programació, els claudàtors representen un <strong>Array</strong>, és a dir, una col·lecció de dades agrupades. D'aquesta manera l'Aon interpreta allò dintre del claudàtor com un grup d'elements que van tots units en l'espai d'un sol temps. Això ens facilita fer "rolls" o repeticions de Trance!
          </p>
        </div>
        
        <p>
          En el següent exemple el segon grup ha estat subdividit en "caixa caixa caixa", reproduint tres vegades la caixa durant just l'instant de temps que li hagués tocat. També tenim el modificador <code>.ràpid()</code> per alterar la velocitat de tot un bloc.
        </p>

        <CodeBox 
          setCode={setCode} 
          description="Obre aquest exemple, i escolta com de trepidants sonen les 3 caixes del segon pas gràcies a l'Array de subdivisió, creant estructures complexes al llarg del temps."
          code={'so("bombo [caixa caixa caixa] bombo [xarles xarles xarles xarles]").ràpid(1.5)'} 
        />
        
        <CodeBox 
          setCode={setCode} 
          description="També podem incloure pauses inserint el caràcter ~. Intenta aquest patró estacat:"
          code={'so("bombo ~ [caixa ~ caixa] bombo").ràpid(2)'} 
        />

        <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm my-6">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-3 font-display flex gap-2 items-center">
            ✖️ Multiplicació i Subdivisions (*)
          </h3>
          <p className="text-sm text-slate-600 mb-4 font-medium leading-relaxed">
            I si volem que una percussió soni diverses vegades ràpidament ocupant el mateix espai de temps? A Aon pots utilitzar el símbol de multiplicació (l'asterisc <code className="bg-slate-100 font-mono text-[13px] px-1 rounded">*</code>) seguit d'un número just després d'un instrument per subdividir aquell espai de temps exactament. Per exemple, <code className="bg-slate-100 font-mono text-[13px] px-1 rounded">obert*3</code> tocarà tres platerets oberts en el mateix temps que ocuparia un de sol (substituint així la necessitat de crear arrays repetitius tipus <code className="bg-slate-100 font-mono text-[13px] px-1 rounded">[obert obert obert]</code>).
          </p>

          <div className="space-y-4">
            <CodeBox 
              setCode={setCode} 
              description="Aplica la multiplicació (*2, *3, *4...) per subdividir els temps i crear ritmes molt més complexos i ràpids, ideals per a redoblaments de bateria."
              code={'so("bombo obert*3 caixa xarles*4")'} 
            />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm my-6">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-3 font-display flex gap-2 items-center">
            🔄 Alternació ciclada i Control del Decaïment (.dec)
          </h3>
          <p className="text-sm text-slate-600 mb-4 font-medium leading-relaxed">
            Explorem una estructura increïblement potent en el món del Live Coding: <code className="bg-slate-100 font-mono text-[13px] px-1 rounded">so("[bombo &lt;xarles obert&gt;]*2").dec(0.4)</code> (o en l'equivalent de Strudel de baix nivell <code className="bg-slate-100 font-mono text-[13px] px-1 rounded">s("[bd &lt;hh oh&gt;]*2").dec(.4)</code>).
          </p>
          <p className="text-sm text-slate-600 mb-4 font-medium leading-relaxed">
            Aquesta línia de codi combina conceptes clau molt expressius d'Aon:
          </p>
          <ul className="space-y-2.5 text-sm text-slate-600 mb-5 pl-5 list-disc leading-relaxed font-medium">
            <li>
              <strong>Alternació amb angulars <code className="bg-slate-100 font-mono text-[12px] px-1 rounded">&lt; &gt;</code>:</strong> El paràmetre <code className="text-indigo-600 font-semibold font-mono">&lt;xarles obert&gt;</code> tria un so diferent a cada volta! Al cicle 1 tocarà el <code className="font-semibold font-mono">xarles</code>, i al cicle 2 tocarà l'<code className="font-semibold font-mono">obert</code>, produint un ritme viu i gens monòton.
            </li>
            <li>
              <strong>Subdivisió repetida <code className="bg-slate-100 font-mono text-[12px] px-1 rounded">*2</code>:</strong> El conjunt format del bombo i l'alternador es repetirà exactament 2 vegades per cicle.
            </li>
            <li>
              <strong>Decaïment de pols <code className="bg-slate-100 font-mono text-[12px] px-1 rounded">.dec(0.4)</code>:</strong> (Abreviatura de <em>decay</em>) Les cues d'ona es configuren a només 0.4 segons de durada, escurçant el final de cada so per aconseguir una textura super neta, dinàmica i tallada a nivell minimal techno o microhouse!
            </li>
          </ul>

          <div className="space-y-4">
            <CodeBox 
              setCode={setCode} 
              description="Prova aquest ritme hipnotitzant a l'editor. Observa com el segon pas alterna automàticament entre el xarles i l'obert a cada cicle de so!"
              code={'so("[bombo <xarles obert>]*2")\n  .dec(0.4)'} 
            />
          </div>
        </div>

        <div className="mt-8 p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 shadow-sm shadow-emerald-100/50">
          <h3 className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎯 Repte:</h3>
          <p className="text-sm text-slate-600 font-medium">Prova afegir petites subdivisions tipus <code>[xarles xarles]</code> dins un dels teus ritmes i escolta l'increment d'agressivitat al ritme.</p>
        </div>
      </div>
    ),
    initialCode: ''
};
