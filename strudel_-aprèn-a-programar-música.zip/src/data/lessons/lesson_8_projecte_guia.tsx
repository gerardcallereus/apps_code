import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_8_projecte_guia: Lesson = {
    id: '10-projecte-guia',
    title: '11. Guia per Produir una Cançó',
    icon: BookOpen,
    content: ({ setCode }) => (
      <div className="space-y-4">
        <p>
          Crear una cançó electrònica moderna des de zero requereix seguir cert ordre per no barrejar massa idees. Anem a revisar l'ordre de construcció d'elements que és més robust habitualment.
        </p>
        
        <div className="space-y-6 my-6 p-4 rounded-xl border border-slate-200 bg-white/50">
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold font-display shrink-0 shadow-md">1</div>
            <div>
              <h4 className="font-bold text-slate-800 tracking-tight text-[15px] mb-1">El Pes (Bateria i Tempo)</h4>
              <p className="text-sm text-slate-600">Primer un <code>bpm(130)</code> seguit per un <code>const drums = so("bombo caixa").ràpid(2)</code> llança les bases i diu a quina velocitat va tot, preparant per un bon Techno o House.</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-rose-500 text-white flex items-center justify-center font-bold font-display shrink-0 shadow-md">2</div>
            <div>
              <h4 className="font-bold text-slate-800 tracking-tight text-[15px] mb-1">Bassline Grooves</h4>
              <p className="text-sm text-slate-600">Crea el subsòl tàctic amb <code className="text-xs">so("triangle")</code> buscant els espais on la bateria "suavitza el cop" (amb descansos visuals on hi havíen un ~ per donar pes de retorn).</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold font-display shrink-0 shadow-md">3</div>
            <div>
              <h4 className="font-bold text-slate-800 tracking-tight text-[15px] mb-1">Capa Melòdica Texturada (Lead)</h4>
              <p className="text-sm text-slate-600">Aprofita un sintetitzador <code className="text-xs">serra</code> tallant les estridències amb <code className="text-xs">filtreGreus</code> i que faci un arpegi ben actiu acompanyat de atzar per trencar la monotonia constant.</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold font-display shrink-0 shadow-md">4</div>
            <div>
              <h4 className="font-bold text-slate-800 tracking-tight text-[15px] mb-1">Atmosfera i Espai (Room)</h4>
              <p className="text-sm text-slate-600">Sense els silencis una cançó només és soroll estrident; utilitza seqüències lentes o silencis i acompanya fins el final amb una capa <code>sinusoide</code> plena de reverberació <code>ressò()</code> a les esquenes.</p>
            </div>
          </div>
          <div className="flex gap-4 mt-8 pt-4 border-t border-slate-200">
            <div className="w-8 h-8 rounded-xl bg-violet-500 text-white flex items-center justify-center shrink-0 shadow-md"><Code2 size={16}/></div>
            <div>
               <h4 className="font-bold text-slate-800 tracking-tight text-[15px] mb-1">Construeix el Mur d'Estètic</h4>
              <p className="text-sm text-slate-600">Ho tindràs tot preparat, invoca tots els elements passant en ordre al motor de <code>capes()</code>!</p>
            </div>
          </div>
        </div>

        <CodeBox 
          setCode={setCode} 
          description="Fixa't aquí tenim representades les 4 fases a punt abans de llançar la funció universal a producció:"
          code={`bpm(130)\n\n/* 1. base */\nconst drums = so("bombo xarles bombo caixa")\n\n/* 2. els grooved basos */\nconst basses = nota("do3 ~ fa3 ~").instrument("triangle")\n\n/* 3. els synths extrems */\nconst keys = nota("sol4 mi4 la4 ~ sol4").instrument("serra").filtreGreus(1200).barreja(2)\n\n/* 4. ambient i pads llunyans */\nconst celestial = nota("~ do6 ~ ~").instrument("sinusoide").ressò(0.9)\n\n/* Apilats */\ncapes(drums, basses, keys, celestial).ràpid(2)`} 
        />
      </div>
    ),
    initialCode: ''
};
