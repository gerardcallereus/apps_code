import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_6_efectes: Lesson = {
    id: '6-efectes',
    title: '7. Efectes d\'Ambient i Espai',
    icon: Wand2,
    content: ({ setCode }) => (
      <div className="space-y-4">
        <p>
          L'espaialitat es genera fonamentalment jugant amb <strong>resonàncies i ecos</strong> (Rooms i reverbs) o amb moviments d'estereofonia entre ambdós altaveus o auriculars.
        </p>
        <ul className="list-disc pl-5 space-y-2 marker:text-indigo-300">
          <li><code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">.ressò(0.5)</code>: Dona l'efecte d'estar en una sala de reverberacions. Et fa sentir tota la cua. Utilitza 0.8 per a simular autèntiques catedrals sonores o 0.1 per espais tancats.</li>
          <li><code className="bg-white border border-slate-200 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] shadow-sm">.panorama(0.2)</code>: Fa que la música surti més per l'esquerra (0.0) o per la dreta (1.0). Si escriem una matriu (Array) <code>.panorama("0.1 0.9")</code> el so ballarà d'esquerra a dreta completament.</li>
        </ul>

        <CodeBox 
          setCode={setCode} 
          description="Escolta l'atmosfera que deixa aquest sine gràcies al ressò i al panorama extrems. Fins i tot un cop fas Stop temporalment, la cua de reverberació trigarà minuts esfumar-se."
          code={'nota("do4 do3 la4").instrument("sinusoide").ressò(0.9).panorama("0 1 0.5").ràpid(1.5)'} 
        />

        <div className="mt-8 p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100 shadow-sm shadow-emerald-100/50">
          <h3 className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎯 Repte:</h3>
          <p className="text-sm text-slate-600 leading-loose font-medium">
            Posa't uns auriculars i varia el paràmetre '.panorama()' posant gradualment un <code className="bg-white border border-slate-200 text-rose-500 px-1 py-0.5 rounded-md font-mono text-[12px] shadow-sm">.panorama(1)</code> o un <code className="bg-white border border-slate-200 text-rose-500 px-1 py-0.5 rounded-md font-mono text-[12px] shadow-sm">.panorama(0)</code> a seques per escoltar tot només per un fil!
          </p>
        </div>
      </div>
    ),
    initialCode: ''
};
