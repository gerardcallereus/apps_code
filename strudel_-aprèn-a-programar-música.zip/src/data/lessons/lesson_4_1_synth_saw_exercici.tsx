import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_4_1_synth_saw_exercici: Lesson = {
    id: '4.1-synth-saw-exercici',
    title: '5.1 Exercici de Filtres',
    icon: Target,
    content: () => (
      <div className="space-y-4">
        <p className="text-lg text-slate-800 font-medium">L'Art de l'Acid Techno</p>
        <p className="text-slate-600">
          Ja coneixes el synth electrònic pur, a veure si saps domar-lo fent servir el Filtre Pas Baix (Low Pass Filter) per fer sonar una línia àcida.
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">📝 Requisits:</h4>
          <ul className="list-disc pl-5 text-sm text-slate-700 font-medium marker:text-indigo-300 space-y-2">
            <li>Utilitza l'instrument <code>so("serra")</code> sobre les notes donades per activar l'oscil·lador.</li>
            <li>Afegeix l'efecte <code>.filtreGreus(400)</code> assegurant que passes exactament el paràmetre (400) per crear el famós toc fosc i bombollejant Àcid.</li>
          </ul>
        </div>
      </div>
    ),
    initialCode: '',
    exercise: {
      successMessage: "Enhorabona! Tens sota control el so Acid de la Roland TB-303.",
      onCheck: (code) => {
        const hasSawtooth = code.includes('instrument("serra")') || code.includes("instrument('serra')") || code.includes('so("serra")') || code.includes("sawtooth");
        const hasLPF = code.includes(".filtreGreus(");
        
        if (!hasSawtooth) return { success: false, message: 'Ens falta especificar que volem un element amb instrument serra.' };
        if (!hasLPF) return { success: false, message: 'Aplica .filtreGreus(...) a la línia on tenim el synth.' };
        if (!code.includes("400")) return { success: false, message: 'Recorda tallar concretament el filtre enviant el paràmetre 400 .filtreGreus(400).' };
        
        return { success: true, message: "Perfecte! Superats tots els passos de la textura." };
      }
    }
};
