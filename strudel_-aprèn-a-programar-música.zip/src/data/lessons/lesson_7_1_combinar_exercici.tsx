import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_7_1_combinar_exercici: Lesson = {
    id: '9.1-combinar-exercici',
    title: "10.1 Exercici d'Arquitectura",
    icon: Target,
    content: () => (
      <div className="space-y-4">
        <p className="text-lg text-slate-800 font-medium">Apilant l'art sencer</p>
        <p className="text-slate-600">
          Construeix l'organigrama central de qualsevol cançó des de zero abans d'iniciar les de de debò. Apila les capes existents al motor intern.
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">📝 Requisits:</h4>
          <ul className="list-disc pl-5 text-sm text-slate-700 font-medium marker:text-indigo-300 space-y-2">
            <li>Identifica on declaren explícitament la variable `ritme` i la variable `acid` i no les destrueixis!</li>
            <li>Inicilitza un mètode final de bucle <code>capes()</code> i encabeix els dos noms a l'interior com a entrades (separades per una coma entre si).</li>
          </ul>
        </div>
      </div>
    ),
    initialCode: '',
    exercise: {
      successMessage: "Excel·lent. Arquitectura neta i funcional llesta pel pas important.",
      onCheck: (code) => {
        const hasStack = code.includes("capes(");
        const stackContentVariables = code.includes("ritme") && code.includes("acid");
        
        if (!hasStack) return { success: false, message: "No percebo cap declaració de capes(), sense això no ajuntem res." };
        if (!stackContentVariables) return { success: false, message: "Les variables (ritme, acid) no estan totes subministrades dins per tocar en viu." };
        
        return { success: true, message: "Perfecte! Preparació finalitzada." };
      }
    }
};
