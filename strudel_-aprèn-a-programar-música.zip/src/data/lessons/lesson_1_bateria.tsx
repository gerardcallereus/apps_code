import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_1_bateria: Lesson = {
    id: '1-bateria',
    title: '1. Bateria (Drum Set)',
    icon: Drum,
    content: ({ setCode }) => (
      <div className="space-y-5">
        <p>
          Benvingut/da a <strong>Aon</strong>! Farem música escrivint codi (Live Coding). El corrent de Live Coding ens ensenya a crear patrons musicals sobre la marxa programant-los, donant peu a actuacions sorprenents i al desenvolupament de cançons completament a partir de text.
        </p>
        
        <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-3 font-display flex gap-2 items-center">
            🥁 La Funció de So (s) i la Bateria
          </h3>
          <p className="text-sm text-slate-600 mb-4 font-medium leading-relaxed">
            A l'Aon, la funció principal per reproduir un so de percussió o instrument és <code className="bg-slate-100 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] border border-slate-200">so()</code> (abreviatura de <em>sound</em>). Entre els parèntesis i unes cometes dobles <code className="bg-slate-100 font-mono text-[13px] px-1 rounded">" "</code> introduirem les síl·labes (samples) que volem que sonin. Un dels kits més utilitzats és el de bateria tradicional o <em>drum set</em>.
          </p>
          <img src="https://strudel.cc/img/drumset.png" alt="Drumset Aon" className="w-full max-w-sm mx-auto mix-blend-multiply rounded-lg mb-5" />
          <div className="grid sm:grid-cols-2 gap-4 text-sm font-mono text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-100">
            <div>
              <p className="font-bold text-slate-900 border-b border-slate-200 pb-1 mb-2 font-sans text-xs uppercase tracking-wider">Peces Principals</p>
              <ul className="space-y-1.5">
                <li><strong className="text-indigo-600">bombo</strong> <span className="text-slate-500 font-sans text-xs">(bass drum)</span> - Bombo greu</li>
                <li><strong className="text-indigo-600">caixa</strong> <span className="text-slate-500 font-sans text-xs">(snare drum)</span> - Caixa / Redoblant</li>
                <li><strong className="text-indigo-600">xarles</strong> <span className="text-slate-500 font-sans text-xs">(hihat)</span> - Plat tancat</li>
                <li><strong className="text-indigo-600">obert</strong> <span className="text-slate-500 font-sans text-xs">(open hihat)</span> - Plat obert</li>
              </ul>
            </div>
            <div>
              <p className="font-bold text-slate-900 border-b border-slate-200 pb-1 mb-2 font-sans text-xs uppercase tracking-wider">Percussió i Detalls</p>
              <ul className="space-y-1.5">
                <li><strong className="text-indigo-600">plateret</strong> <span className="text-slate-500 font-sans text-xs">(crash / ride)</span> - Plats de remat</li>
                <li><strong className="text-indigo-600">palmes</strong> <span className="text-slate-500 font-sans text-xs">(claps)</span> - Cops de palmelles</li>
                <li><strong className="text-indigo-600">rim</strong> <span className="text-slate-500 font-sans text-xs">(rimshot)</span> - Cop de vora</li>
                <li><strong className="text-indigo-600">~</strong> <span className="text-slate-500 font-sans text-xs">(rest)</span> - Un espai en silenci!</li>
              </ul>
            </div>
          </div>
        </div>
        
        <p className="text-slate-700 font-medium leading-relaxed">
          <strong>A dissenyar ritmes!</strong> El text que posem a dins de <code className="bg-white border text-rose-500 text-sm px-1 rounded shadow-sm">so("...")</code> el llegirà d'esquerra a dreta de forma seqüencial repartint l'espai i el temps equitativament. Fixat en els diferents estils i prova d'obrir-los directament a l'editor (només has de donar al botó de Play verd o fer servir <kbd className="bg-slate-200 border-b-2 border-slate-300 rounded px-1.5 text-xs text-slate-600 font-sans">Shift+Enter</kbd>).
        </p>

        <div className="space-y-4">
          <CodeBox 
            setCode={setCode} 
            description="Ritme clàssic (Four on the Floor) de TECHNO / TRANCE: El bombo (bombo) marca tots els temps forts, afegint pes inansable a la pista de ball."
            code={'so("bombo bombo bombo bombo")'} 
          />
          <CodeBox 
            setCode={setCode} 
            description="El típic ritme de música HOUSE i Groove: Bombo - Xarles - Caixa - Palmes."
            code={'so("bombo xarles caixa palmes")'} 
          />
          <CodeBox 
            setCode={setCode} 
            description="L'ús del silenci (~): Podem crear síncopes (contratemps) i descansos substituint un cop per un espai amb l'oneta (la tilde ~)."
            code={'so("bombo ~ caixa xarles")'} 
          />
          <CodeBox 
            setCode={setCode} 
            description="Introduint Tom-Toms: Tambors que s'utilitzen normalment per fer 'Fills' o talls rematant la frase."
            code={'so("bombo tomagut tommig tomgreu")'} 
          />
          <CodeBox 
            setCode={setCode} 
            description="Dibuixant seqüències llargues i combinades: Pots escriure literalment tots els cops que vulguis, la flexibilitat de la programació t'ho permet!"
            code={'so("bombo xarles caixa xarles bombo bombo caixa plateret")'} 
          />
        </div>

        <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm my-6">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-3 font-display flex gap-2 items-center">
            🎛️ Variacions i Diferents Llibreries
          </h3>
          <p className="text-sm text-slate-600 mb-4 font-medium leading-relaxed">
            Un instrument no s'ha de limitar a sonar sempre igual! Podem triar diferents arxius d'àudio de la llibreria per defecte utilitzant els dos punts (:) i un número. A més a més, Aon ens permet carregar llibreries completes de sons alternatius utilitzant la instrucció <code className="bg-slate-100 text-rose-600 px-1.5 py-0.5 rounded-md font-mono text-[13px] border border-slate-200">llibreria(...)</code> al principi del codi. Així, les paraules que ja coneixes (com bombo o caixa) prendran una textura i cos completament diferents.
          </p>

          <div className="space-y-4">
            <CodeBox 
              setCode={setCode} 
              description="Utilitza els 2 punts (:) al costat del nom de l'instrument per escoltar variacions incloses a la llibreria."
              code={'so("bombo:0 bombo:1 bombo:2 bombo:3")'} 
            />
            <CodeBox 
              setCode={setCode} 
              description="Escriu llibreria(antics) a dalt de tot per carregar l'Aon amb la col·lecció de percussions llegendària de TidalCycles (Dirt-Samples). El pes i el to canvien radicalment!"
              code={'llibreria(antics)\n\nso("bombo caixa obert caixa")\n  .ràpid(1.5)'} 
            />
          </div>
        </div>

        <div className="mt-8 p-5 rounded-2xl bg-emerald-50/50 border border-emerald-200 shadow-sm shadow-emerald-100/50">
          <h3 className="text-[13px] font-bold text-emerald-600 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">🎯 Repte pràctic:</h3>
          <p className="text-sm text-slate-700 font-medium leading-relaxed">Obre a l'editor "bombo xarles caixa xarles", i prova d'afegir-hi més notes a dins i canviar-ne l'ordre (per exemple: inventa't <code className="bg-white/50 px-1 rounded text-emerald-800">bombo ~ caixa ~ bombo xarles</code>). Observa com el programa intenta tocar totes les notes en el mateix espai de temps d'un cicle, anant més ràpid si poses moltes síl·labes juntes!</p>
        </div>
      </div>
    ),
    initialCode: ''
};
