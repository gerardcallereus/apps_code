import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_2_1_sequencies_exercici: Lesson = {
    id: '2.1-sequencies-exercici',
    title: '2.1 Exercici de seqüències',
    icon: Target,
    content: () => (
      <div className="space-y-4">
        <p className="text-lg text-slate-800 font-medium">L'art de la subdivisió de House o Trance</p>
        <p className="text-slate-600">
          En aquest exercici comprovarem si domines la subdivisió mitjançant les llistes <code className="bg-slate-100 px-1 rounded">[ ]</code>.
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">📝 Requisits:</h4>
          <ul className="list-disc pl-5 text-sm text-slate-700 font-medium marker:text-indigo-300 space-y-2">
            <li>Construeix un patró que inclogui exactament l'agrupació de tres caixes ràpides: <code>[caixa caixa caixa]</code>.</li>
            <li>El ritme complet ha d'accelerar-se utilitzant el mètode <code>.ràpid(2)</code> o similar encadenat al final per donar-li energia Trance.</li>
          </ul>
        </div>
      </div>
    ),
    initialCode: '',
    exercise: {
      successMessage: "Increïble! Ja saps agrupar passos com els professionals i modificar el temps d'una línia Trance o Techno.",
      onCheck: (code) => {
        const hasSubdivision = /so\(\s*['"][^'"]*\[caixa\s+caixa\s+caixa\][^'"]*['"]\s*\)/.test(code);
        const hasFast = /\.ràpid\([^)]+\)/.test(code);
        
        if (!hasSubdivision) {
          return { success: false, message: 'Ens falta identificar la subdivisió de caixes "[caixa caixa caixa]" dintre de la crida a so(). Recorda posar-ho entre cometes!' };
        }
        if (!hasFast) {
          return { success: false, message: 'Assegurat de posar .ràpid() darrera per modificar la velocitat del patró complet!' };
        }
        
        return { success: true, message: "Fantàstic! Tens un domini del ritme brutal." };
      }
    }
};
