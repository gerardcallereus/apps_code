import React from 'react';
import { Timer } from 'lucide-react';
import { Lesson } from '../../types';
import { CodeBox } from '../../components/CodeBox';

export const lesson_2_5_bpm: Lesson = {
    id: '2.5-bpm',
    title: '3. Velocitat (BPM)',
    icon: Timer,
    content: ({ setCode }) => (
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-800 mb-3 tracking-tight font-display">Trobant el Ritme</h2>
          <p className="text-slate-600 leading-relaxed font-medium">
            Fins ara has estat component sota un ritme predeterminat (120 batecs per minut o BPM). 
            Però a vegades necessitem un tema lent i ambiental, o bé adaptar el tempo als estils de música electrònica. T'expliquem ràpidament els BPMs habituals:
          </p>
          <ul className="list-disc pl-5 mt-3 text-sm text-slate-700 font-medium marker:text-indigo-300 space-y-1">
            <li><strong>House:</strong> 118 - 126 BPM (Càlid, ritme suau constant)</li>
            <li><strong>Techno:</strong> 130 - 140 BPM (Més pesat i ràpid, industrial)</li>
            <li><strong>Trance:</strong> 138 - 145 BPM (Ràpid i enèrgic, ple d'energia)</li>
            <li><strong>Acid:</strong> Típicament pot ballar sobre 130-140 depenent de si és Acid House o Acid Techno.</li>
          </ul>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm mt-6">
          <p className="text-sm font-bold text-slate-800 mb-3">La instrucció bpm()</p>
          <p className="text-sm text-slate-600 mb-4 leading-relaxed font-medium">
            Al principi del teu codi, pots fixar la velocitat de tota la composició escrivint <code className="bg-slate-100 text-rose-600 px-1 py-0.5 rounded font-mono text-sm">bpm(valor)</code>.
          </p>
          <CodeBox 
            setCode={setCode} 
            description="Això és un Trance pur! Escolta aquest ritme extrem a 140 BPM (canvia-ho a 120 per notar la diferència i baixar a House):"
            code={'bpm(140)\n\nso("bombo ~ caixa ~").ràpid(2)'} 
          />
        </div>

        <div className="mt-8 p-5 rounded-2xl bg-indigo-50/50 border border-indigo-100 shadow-sm shadow-indigo-100/50">
          <h3 className="text-xs font-bold text-indigo-500 uppercase tracking-wider mb-2 font-display flex gap-2 items-center">💡 Prova-ho:</h3>
          <p className="text-sm text-slate-600 leading-relaxed font-medium">
            Executa l'exemple de dalt i canvia el valor de <code className="font-bold text-indigo-900 border-b border-indigo-200">bpm(140)</code> a <code className="font-bold text-indigo-900 border-b border-indigo-200">bpm(160)</code> per transformar el ritme en Drum & Bass!
          </p>
        </div>
      </div>
    ),
    initialCode: ''
};
