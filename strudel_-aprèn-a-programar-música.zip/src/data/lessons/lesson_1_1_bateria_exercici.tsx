import { FileAudio, Music, ListMusic, Drum, AudioLines, Trophy, Wand2, Sparkles, Target, BookOpen, Code2 } from 'lucide-react';
import React from 'react';
import { CodeBox } from '../../components/CodeBox';
import { Lesson } from '../../types';

export const lesson_1_1_bateria_exercici: Lesson = {
    id: '1.1-bateria-exercici',
    title: '1.1 Exercici de bateries',
    icon: Target,
    content: () => (
      <div className="space-y-4">
        <p className="text-lg text-slate-800 font-medium">Demostra el que has après!</p>
        <p className="text-slate-600">
          En aquest exercici hauràs de crear una base de ball clàssica tipus House utilitzant <strong>bombo</strong>, <strong>caixa</strong> i <strong>xarles</strong>. 
        </p>
        <div className="bg-indigo-50/50 border border-indigo-100 p-5 my-6 rounded-2xl shadow-sm shadow-indigo-100/50">
          <h4 className="text-indigo-500 text-xs font-bold uppercase tracking-wider mb-2 font-display flex gap-2 items-center">📝 Requisits:</h4>
          <ul className="list-disc pl-5 text-sm text-slate-700 font-medium marker:text-indigo-300 space-y-2">
            <li>El codi de l'editor a la teva dreta ha de tenir exactament la paraula <code className="text-rose-600 bg-white px-1 py-0.5 rounded border">so()</code> programada com ensenyàvem.</li>
            <li>Dintre l'String de sons programats hi has d'esmentar la seqüència exacta <code>bombo xarles caixa xarles</code> per formar aquest ritme ballable de club.</li>
          </ul>
        </div>
      </div>
    ),
    initialCode: '',
    exercise: {
      successMessage: "Genial! Això ja sona a club! Estàs preparat per donar més velocitat i complexitat!",
      onCheck: (code) => {
        const hasS = code.includes("so(");
        const hasPattern = code.includes("bombo xarles caixa xarles");
        
        if (!hasS) {
          return { success: false, message: 'El teu codi no conté la crida a la funció so("..."). Recorda invocar l\'instrument!' };
        }
        if (!hasPattern) {
          return { success: false, message: 'La seqüència que has creat no és el patró requerit. Recorda que ha de ser exactament "bombo xarles caixa xarles" dintre dels parèntesis i cometes de so()!' };
        }
        
        return { success: true, message: "Perfecte!" };
      }
    }
};
